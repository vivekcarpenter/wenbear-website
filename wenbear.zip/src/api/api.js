const baseUrl = "http://localhost:8000/api";


export default baseUrl;